// 計算を実行する
function doCalc() {
    var x = document.getElementById('x');
    var y = document.getElementById('y');
    var z = document.getElementById('z');
    z.value = Number(x.value) + Number(y.value);
}

